import { Component, OnInit } from '@angular/core';
import { TestApiService } from './../core/services/testapi.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Validator } from '../core/services/validation.service';
import { CommanService } from './../core/services/comman.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(private testApiService : TestApiService,
    private formBuilder: FormBuilder,
    private router:Router,
    private validator:Validator,
    private commanService: CommanService) { }
 
  log: FormGroup;
  ngOnInit() {
    this.log = this.formBuilder.group({
      email:['',[Validators.required]],
      password: ['', [Validators.required]]
    });
      
  }

  loginUser(login){
    if(!login.valid){
      this.commanService.makeFormFieldTouched(login.controls);
      return;
    }else{
      this.testApiService.login(login.value).subscribe((result: any)=> { 
      if(result.status){
         localStorage.setItem('user'  ,JSON.stringify(result.data[0]));
          if(result.data[0].m_isActive == 1)
        this.router.navigate(['/ad/emp']);
      else
        this.router.navigate(['/testlist']);
         }else{
        alert(result.message);
      }
      // if(result.status){ 
      //   alert(result.message);
      // this.router.navigate(['/testlist']);
      // }else{
      //   alert(result.message);
      // }
    },error => {
      alert(error);
    });
  
    }
    
  	
  }
  getErrorMessage(type) {
    switch (type) {
      case "email":
        return this.log.get('email').hasError('required') ? 'Email required' : '';
      case "pass":
        return this.log.get('password').hasError('required') ? 'Password required' : '';
      default:
        return 'Please fill all details';
    }
  }
}
