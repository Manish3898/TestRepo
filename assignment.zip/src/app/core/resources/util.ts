export class Util {
	public staticDefaultSettings = {
		bcc: "test@gmail.com",
		city: "bhopal",
		ctry: "101",
		duration: "01:00",
		email: "a@gmail.com",
		state: "22"
	}
	constructor() { }

	getRandomInt(min, max) {
		min = Math.ceil(min);
		max = Math.floor(max);
		return Math.floor(Math.random() * (max - min)) + min; //The maximum is exclusive and the minimum is inclusive
	}
	getIndexOfArrayData(data, property, value) {
		let result = -1;
		data.some(function (item, i) {
			if (item[property] === value) {
				result = i;
				return true;
			}
		});
		return result;
	}
	getLoginUser() {
		let user: any = localStorage.getItem('wms_admin_details') != "undefined" ? (localStorage.getItem('wms_admin_details')) : null;
		if (user) {
			user = JSON.parse(window.atob(user));
		}
		return user;
	}
	setLoginUser(data) {
		let enc = window.btoa(JSON.stringify(data));
		localStorage.setItem('wms_admin_details', enc);
	}
	getLoginAdmin() {
		let user = localStorage.getItem('wms_superAdmin_details') != "undefined" ? JSON.parse(localStorage.getItem('wms_superAdmin_details')) : null;
		return user;
	}
	//set remember detail
	setRememberPassword(val) {
		let enc = window.btoa(JSON.stringify(val));
		localStorage.setItem('wms_rememberMeDetail', enc);
	}
	//get remember detail
	getRememberPassword() {
		let rememberUsr: any = localStorage.getItem('wms_rememberMeDetail') != "undefined" ? (localStorage.getItem('wms_rememberMeDetail')) : null;
		if (rememberUsr) {
			rememberUsr = JSON.parse(window.atob(rememberUsr));
		}
		return rememberUsr;
	}
	//remove remember detail
	removeRememberPassword() {
		localStorage.removeItem('wms_rememberMeDetail');
	}

	
	/*get brId by array */
	convertBranchIdArray(data) {
		let brIdArray = [];
		for (let dataId of data) {
			brIdArray.push(dataId.brId);
		}
		return brIdArray;
	}

	/**
	 * Convert an integer to its words representation
	 * 
	 * @author McShaman (http://stackoverflow.com/users/788657/mcshaman)
	 * @source http://stackoverflow.com/questions/14766951/convert-digits-into-words-with-javascript
	 */
	numberToEnglish(num) {
		num = Math.round(parseFloat(num));
		if (num == 0) {
			return 'Zero';
		}
		else if (num < 1) {
			num = parseFloat(num) * 10000000;
			return this.convertFloatValueIntoWords(num);
		} else {
			if (this.isFloat(num)) {
				// let's get the position of the radix-point
				var radixPos = String(num).indexOf('.');

				// now we can use slice, on a String, to get '.15'
				var pointValue = String(num).slice(radixPos);
				return this.converIntValueIntoWords(Math.floor(num)) + ' and ' + this.convertFloatValueIntoWords(parseFloat(pointValue) * Math.pow(10, String(pointValue).length - 1)) + 'only ';

			} else {
				return this.converIntValueIntoWords(Math.floor(num))
			}
			//num = parseFloat(num) * 10000000;
		}
	}

	converIntValueIntoWords(num) {
		var a = ['', 'one ', 'two ', 'three ', 'four ', 'five ', 'six ', 'seven ', 'eight ', 'nine ', 'ten ', 'eleven ', 'twelve ', 'thirteen ', 'fourteen ', 'fifteen ', 'sixteen ', 'seventeen ', 'eighteen ', 'nineteen '];
		var b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
		if ((num = num.toString()).length > 9) return 'overflow';
		var n: any = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
		if (!n) return; var str = '';
		str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
		str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
		str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
		str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
		str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + '' : '';
		return str;
	}

	convertFloatValueIntoWords(num) {
		var a = ['', 'one ', 'two ', 'three ', 'four ', 'five ', 'six ', 'seven ', 'eight ', 'nine ', 'ten ', 'eleven ', 'twelve ', 'thirteen ', 'fourteen ', 'fifteen ', 'sixteen ', 'seventeen ', 'eighteen ', 'nineteen '];
		var b = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];
		if ((num = num.toString()).length > 9) return 'overflow';
		var n: any = ('000000000' + num).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
		if (!n) return; var str = '';
		str += (n[1] != 0) ? (a[Number(n[1])] || b[n[1][0]] + ' ' + a[n[1][1]]) + 'crore ' : '';
		str += (n[2] != 0) ? (a[Number(n[2])] || b[n[2][0]] + ' ' + a[n[2][1]]) + 'lakh ' : '';
		str += (n[3] != 0) ? (a[Number(n[3])] || b[n[3][0]] + ' ' + a[n[3][1]]) + 'thousand ' : '';
		str += (n[4] != 0) ? (a[Number(n[4])] || b[n[4][0]] + ' ' + a[n[4][1]]) + 'hundred ' : '';
		str += (n[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(n[5])] || b[n[5][0]] + ' ' + a[n[5][1]]) + 'only ' : '';
		return str;
	}

	isInt(n) {
		return Number(n) === n && n % 1 === 0;
	}

	isFloat(n) {
		return Number(n) === n && n % 1 !== 0;
	}
}
