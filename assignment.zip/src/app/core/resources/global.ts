// import { environment } from '../../../environments/environment';

// //json export 

// export const Client = 'client';


// export const addClient = Client + '/addClient';

// export const FieldWorker = 'fieldWorker';
// export const getTZ = 'assets/json/timezones.json';


// export const addFieldWorker = FieldWorker + '/addField';

// export const currencyJson = 'assets/json/currency.json';
// //export const getFinanceDetail = 'assets/json/finance.json';

// //## Server Api's
// export const base_url= environment.BASE_URL;
// export const API_ENDPOINT= environment.API_ENDPOINT;

// export const authenticationController = API_ENDPOINT+'AuthenticationController';
// export const jobController = API_ENDPOINT+'JobController';
// export const commodityController = API_ENDPOINT+'CommodityController';
// export const userController = API_ENDPOINT+'UserController';
// export const companyController = API_ENDPOINT+'CompanyController';
// export const invoiceController = API_ENDPOINT+'InvoiceController';
// export const quotationController = API_ENDPOINT+'QuotationController';
// export const weighbridgeController = API_ENDPOINT+'WeighbridgeController';

// export const warehouseController = API_ENDPOINT+'WarehouseController'
// export const InsuranceController = API_ENDPOINT+'InsuranceController';
// export const CommodityparametersController = API_ENDPOINT+'CommodityparametersController';
// export const BankController = API_ENDPOINT+'BankController';
// export const LaboratoryController = API_ENDPOINT+'LaboratoryController';
// export const InwardController = API_ENDPOINT+'InwardController';
// export const OutwardController = API_ENDPOINT+'OutwardController';
// export const BranchController = API_ENDPOINT+'BranchController';
// export const FinanceController = API_ENDPOINT+'FinanceController';
// export const ContractController = API_ENDPOINT+'ContractController';
// export const TransferController = API_ENDPOINT+'TransferController';
// export const CMController = API_ENDPOINT+'CMController';


// //Authentication
// export const adminLogin = authenticationController+'/login';
// export const adminLogout = userController+'/logout';
// export const isSessionSet = authenticationController + '/isSessionSet';

// //Clients
// export const getClientList = companyController+'/getClientList';
// export const getJobClientList = companyController+'/getJobClientList';
// export const addClient_ = companyController+'/addClient';
// export const updateClient = companyController+'/updateClient';
// export const getClientDetail = companyController+'/getClientDetail';
// export const deleteClient = companyController+'/deleteClient';

// //Insurance
// export const getWarehouseListByInsurance = InsuranceController+'/getWarehouseListByInsurance';
// export const getChamberListByInsurance = InsuranceController+'/getChamberListByInsurance';
// export const getInsurance = InsuranceController+'/getInsuranceList';
// export const addInsurance = InsuranceController+'/addInsurance';
// export const updateInsurance = InsuranceController+'/updateInsurance';
// export const deleteInsurance = InsuranceController+'/deleteInsurance';
// export const getInsuranceDetail = InsuranceController+'/getInsuranceDetail';
// export const addTopup = InsuranceController+'/addTopup';
// export const updateTopup = InsuranceController+'/updateTopup';
// export const deleteTopup = InsuranceController+'/deleteTopup';
// export const getTopUpList = InsuranceController+'/getTopupList';


// //Finance
// export const getFinance = FinanceController+'/getFinanceList';
// export const getFinanceDetail = FinanceController+'/getFinanceDetail';
// export const addFinance = FinanceController+'/addFinance';
// export const updateFinance = FinanceController+'/updateFinance';
// export const deleteFinance = FinanceController+'/deleteFinance';

// export const getSiteList = companyController+'/getClientSiteList';
// export const addSite = companyController+'/addClientSite';
// export const updateSite = companyController+'/updateClientSite';
// export const getSiteDetail = companyController+'/getClientSiteDetail';
// export const deleteSite = companyController+'/deleteClientSite';

// export const getContactList = companyController+'/getClientContactList';
// export const addContact = companyController+'/addClientContact';
// export const updateContact = companyController+'/updateClientContact';
// export const getContactDetail = companyController+'/getClientContactDetail';
// export const deleteContact = companyController+'/deleteClientContact';
// //WHRF CM request api
// export const updateCMRequest = CMController+'/updateCMRequest';
// export const addCMRequest = CMController+'/addCMRequest';
// export const getCMRequestList = CMController+'/getCMRequestList';
// export const getCMRequestDetail = CMController+'/getCMRequestDetail';
// export const deleteCMRequest = CMController+'/deleteCMRequest';
// export const getLeinWHRList = CMController+'/getLeinWHRList';
// export const getLeinNotingList = CMController+'/getLeinNotingList';
// export const addLeinNoting = CMController+'/addLeinNoting';
// export const deleteLeinNoting = CMController+'/deleteLeinNoting';
// export const removeLeinNoting = CMController+'/removeLeinNoting';
// export const updateLeinNoting = CMController+'/updateLeinNoting';
// export const getLeinNotingDetail = CMController+'/getLeinNotingDetail';
// export const getAllLotOnWHR = CMController+'/getAllLotOnWHR';
// export const getLotsDetailOnWHR = CMController+'/getLotsDetailOnWHR';

// //end
// //Settings
// export const companyDefaultSetting = companyController+'/updateCompanyDetail';

// export const addClientAccountType = companyController+'/addCompanyAccountType';
// export const getClientAccountTypeList = companyController+'/getCompanyAccountTypeList';
// export const getClientAccountDetails = companyController+'/getCompanyAccountDetails';
// export const updateClientAccountType = companyController+'/updateCompanyAccountType';
// export const deleteClientAccountType = companyController+'/deleteCompanyAccountType';

// export const addCompanySetting = companyController+'/addCompanySetting';
// export const getCompanySettingDetails = companyController+'/getCompanySettingDetails';
// export const updateCompanySetting = companyController+'/updateCompanySetting';
// export const deleteCompanySetting = companyController+'/deleteCompanySetting';
// export const updateCompanyJobDuration = companyController+'/updateCompanyJobDuration';
// export const updateCurrency = companyController+'/updateCurrency';
// export const updateCompanyLogo = companyController+'/updateCompanyLogo';

// export const addCompanyTax = companyController+'/addCompanyTax';
// export const getTaxList = companyController+'/getTaxList';
// export const getTaxDetail = companyController+'/getTaxDetail';
// export const updateCompanyTax = companyController+'/updateCompanyTax';
// export const deleteTaxType = companyController+'/deleteTaxType';

// export const addJobTitle = jobController+'/addJobTitle';
// export const getJobTitleList = jobController+'/getJobTitleList';
// export const getJobTitleDetail = jobController+'/getJobTitleDetail';
// export const updateJobTitle = jobController+'/updateJobTitle';
// export const deleteJobTitle = jobController+'/deleteJobTitle';
// export const getCompltionDetails = jobController+'/getCompletionDetail';
// export const addCompletionDetail = jobController+'/addCompletionDetail';
// export const compnyJobSetting = companyController+'/setJobDefaultSetting';
// export const checkClientAndUserEmail = companyController+'/checkClientAndUserEmail';

// /* Chat Module */
// export const getMessageList = jobController + '/getMessageList';
// export const addMessage = jobController + '/addMessage';

// /* Form Api's*/
// export const addForm = jobController+'/addForm';
// export const getFormList = jobController+'/getFormList';
// export const getFormDetail = jobController+'/getFormDetail';
// export const updateForm = jobController+'/updateForm';
// export const deleteForm = jobController+'/deleteForm';
// //export const addQuestion = jobController+'/addQuestion';
// export const addAnswer = jobController+'/addAnswer';
// export const getQuestionsByAnswerId = jobController+'/getQuestionsByAnswerId';
// export const updateQuestion = jobController+'/updateQuestion';
// export const deleteQuestion = jobController+'/deleteQuestion';
// export const getQuestionsByParentId = jobController+'/getQuestionsByParentId';
// export const uploadDocument = jobController+'/uploadDocument';
// export const deleteDocument = jobController+'/deleteDocument';
// export const getJobAttachments = jobController+'/getJobAttachments';

// //User
// export const addUser = userController+'/addUser';
// export const getUserDetails = userController+'/getUserDetail';
// export const getUserContacts = userController+'/getUserContacts';
// // export const updateUser = userController+'/updateUser';
// export const updateUser = userController+'/updateUserByAdmin';
// export const deleteUser = userController+'/deleteUser';
// export const getLoginLog = userController+'/getLoginLog';

// //forgot and change password
// export const forgotPassword = authenticationController+'/forgotPassword';
// export const changePassword = userController+'/changePassword';
// export const forgotPasswordKey = authenticationController+'/forgotPasswordKey';
// export const forgotPasswordReset = authenticationController+'/forgotPasswordReset';


// //Maps
// export const getFieldWorkerList = userController+'/getFieldWorkerList';

// //getRightsList 
// export const getRightsList = userController+'/getRightsList';

// export const Template='<button class="border_button btn-save" type="button" (click) = "searchList(false);">search</button>'

// //Invoice
// export const addInvoice = invoiceController+'/addInvoice';
// export const updateInvoice = invoiceController+'/updateInvoice';
// export const getItemList = invoiceController+'/getItemList';
// export const addItem = invoiceController+'/addItem';
// export const deleteItemImage = invoiceController+'/deleteItemImage';

// export const getItemDetail = invoiceController+'/getItemDetail';
// export const updateItem = invoiceController+'/updateItem';
// export const deleteItem = invoiceController+'/deleteItem';
// export const getInvoiceList = invoiceController+'/getInvoiceList';
// export const getInvoiceDetails = invoiceController+'/getInvoiceDetail';
// export const updateInvoiceSetting = invoiceController+'/updateInvoiceSetting';
// export const getInvoiceSettingDetail = invoiceController+'/getInvoiceSettingDetail';
// export const addPaymentMode = invoiceController+'/invoicePaymentRecieve';
// export const deleteInvoice = invoiceController+'/deleteInvoice';
// export const addStock = invoiceController+'/addStock';
// export const getStockHistory = invoiceController+'/getStockHistory';
// //Job/Jobs
// export const addJob = jobController+'/addJob';
// export const getJobList = jobController+'/getAdminJobList';
// export const getJobDetail = jobController+'/getJobDetail';
// export const updateJob = jobController+'/updateJob';
// export const deleteJob = jobController+'/deleteJob';
// export const getJobStatusHistory = jobController+'/getJobStatusHistory';
// export const getJobTagList = jobController+'/getTagList';
// export const changeJobStatus = jobController+'/changeJobStatus';
// export const changeJobKeeper = jobController+'/changeJobKeeper';
// export const getJobFeedbackList = jobController+'/getJobFeedbackList';
// export const deleteJobFeedback = jobController+'/deleteJobFeedback';
// export const getJobsByRadius = jobController+'/getJobsByRadius';
// export const getFWByRadius = jobController+'/getFieldworkersByRadius';

// //commodity
// export const addCommodity = commodityController+'/addCommodity';
// export const getCommodityList = commodityController+'/getCommodityList';
// export const getCommodityDetail = commodityController+'/getCommodityDetail';
// export const deleteCommodity = commodityController+'/deleteCommodity';
// export const updateCommodity = commodityController+'/updateCommodity';
// export const addCommodityGroup = commodityController+'/addCommodityGroup';
// export const getCommodityGroupList = commodityController+'/getCommodityGroupList';
// export const addCommodityUnit = commodityController+'/addCommodityUnit';
// export const getCommodityUnitList = commodityController+'/getCommodityUnitList';
// export const addCommodityPack = commodityController+'/addCommodityPack';
// export const getCommodityPackList = commodityController+'/getCommodityPackList';
// export const deleteCommodityGroup = commodityController+'/deleteCommodityGroup';
// export const updateCommodityGroup = commodityController+'/updateCommodityGroup';
// export const updateCommodityUnit = commodityController+'/updateCommodityUnit';
// export const deleteCommodityUnit = commodityController+'/deleteCommodityUnit';
// export const deleteCommodityPack = commodityController+'/deleteCommodityPack';
// export const updateCommodityPack = commodityController+'/updateCommodityPack';
// //#region Quotes
// export const addQuote = quotationController+'/addQuotation';
// export const getQuoteList = quotationController+'/getAdminQuoteList';
// export const getQuoteDetail = quotationController+'/getQuoteDetail';
// export const updateQuote = quotationController+'/updateQuotation';
// export const deleteQuote = quotationController+'/deleteQuote';
// export const changeQuotStatus = quotationController+'/changeQuotStatus';
// export const addQuotationInvoice = quotationController+'/addQuotationInvoice';
// export const getQuotationInvoiceDetail = quotationController+'/getQuotationInvoiceDetail';
// export const updateQuotationInvoice = quotationController+'/updateQuotationInvoice';
// export const deleteQuotationInvoice = quotationController+'/deleteQuotationInvoice';
// export const convertQuotationToJob = quotationController+'/convertQuotationToJob';
// //#endregion

// export const importClientData = companyController+'/importClientData';
// /*WMS*/
// export const inwardOutwardJson = 'assets/json/inward_outward.json';
// export const warehouseJson = 'assets/json/warehouse.json';
// export const insuranceJson = 'assets/json/insurance.json';
// export const contractJson = 'assets/json/contract.json';

// export const addWareHouse = warehouseController+'/addWarehouse';
// export const getWareouseList = warehouseController+'/getWareouseList';
// export const getWarehouseDetail = warehouseController+'/getWarehouseDetail';
// export const updateWarehouse = warehouseController+'/updateWarehouse'
// export const deleteWarehouse = warehouseController+'/deleteWarehouse';
// export const getWareouseStackList = warehouseController+'/getWareouseStackList';
// export const addChamberAndStack = warehouseController+'/addChamberAndStack';
// export const updateWarehouseChamber = warehouseController+'/updateWarehouseChamber';
// export const deleteWarehouseChamber = warehouseController+'/deleteWarehouseChamber';

// /**/
// export const addWeighbridge = weighbridgeController+'/addWeighbridge';
// export const getWeighbridge = weighbridgeController+'/getWeighbridgeList';
// export const getWeighbridgeDetail = weighbridgeController+'/getWeighbridgeDetail';
// export const deleteWeighbridgeDetail = weighbridgeController+'/deleteWeighbridge';
// export const updateWeighbridgeDetail = weighbridgeController+'/updateWeighbridge';
// //custom form api
// export const addCommodityParameters = CommodityparametersController+'/addCommodityParameters';
// export const updateCommodityParameters = CommodityparametersController+'/updateCommodityParameters';
// export const getCommodityParametersList = CommodityparametersController+'/getCommodityParametersList';
// export const getCommodityParametersDetail = CommodityparametersController+'/getCommodityParametersDetail';
// export const addQuestion = CommodityparametersController+'/addQuestion';
// export const contractCpLink = CommodityparametersController+'/contractCpLink';
// export const deleteCommodityParameters = CommodityparametersController+'/deleteCommodityParameters';
// //bankBankController/addBank

// export const addBank = BankController+'/addBank';
// export const getBankList = BankController+'/getBankList';
// export const getBankDetail = BankController+'/getBankDetail';
// export const updateBank = BankController+'/updateBank';
// export const deleteBank = BankController+'/deleteBank';
// /*Laboratory */
// export const getLaboratory = LaboratoryController+'/getLaboratoryList';
// export const getLaboratoryDetails = LaboratoryController+'/getLaboratoryDetail';
// export const deleteLaboratory = LaboratoryController+'/deleteLaboratory';
// export const addLaboratory = LaboratoryController+'/addLaboratory';
// export const updateLaboratory = LaboratoryController+'/UpdateLaboratory';
// /*chamber*/
// export const getChamber = warehouseController+'/getWareouseChamberList';
// /*inward */
// export const addInward = InwardController+'/addInwardRequest';
// export const getInwardList = InwardController+'/getInwardRequestList';
// export const deleteInward = InwardController+'/deleteInwardRequest';
// export const getInwardDetails = InwardController+'/getInwardRequestDetail';
// export const upddateInwardDetail = InwardController+'/updateInwardRequest';
// export const transactionInwardList = InwardController+'/getInwardTransactionList';
// export const getInwardTransactionDetails = InwardController+'/getInwardTransactionDetail';
// export const updateInwardTransactionDetails = InwardController+'/updateInwardTransaction';
// export const getCADList = InwardController+'/getCADList';
// export const convertCADtoWHR = InwardController+'/convertCADtoWHR';
// export const getWHRList = InwardController+'/getWHRList';
// export const getWHRDetail = InwardController+'/getWHRDetail';
// export const getCADDetail = InwardController+'/getCADDetail';
// export const linkContractAndInward = InwardController+'/linkContractAndInward';
// export const addInwardTransaction = InwardController+'/addInwardTransaction';
// export const updateCAD = InwardController+'/updateCAD';
// export const updateWHR = InwardController+'/updateWHR';
// export const UnlinkContractAndInward = InwardController+'/UnlinkContractAndInward';
// export const multiCADToWHR = InwardController+'/multiCADToWHR';
// export const addInwardQcDetails = InwardController+'/addInwardQcDetails';
// export const getInwardQcDetails = InwardController+'/getInwardQcDetails';
// export const updateInwardQcDetails = InwardController+'/updateInwardQcDetails';
// export const multiLotToWHR = InwardController+'/multiLotToWHR';
// export const getTollerenceResult = InwardController+'/getTollerenceResult';
// /* Outward */
// export const getOutwardRequestList = OutwardController+'/getOutwardRequestList'
// export const lotSearch = OutwardController+'/lotSearch';
// export const addOutwardRequest = OutwardController+'/addOutwardRequest';
// export const getOutwardRequestDetail = OutwardController+'/getOutwardRequestDetail';
// export const updateOutwardRequest = OutwardController+'/updateOutwardRequest';
// export const deleteOutwardRequest = OutwardController+'/deleteOutwardRequest';
// export const getCDFList = OutwardController+'/getCDFList';
// export const getCDFDetail = OutwardController+'/getCDFDetail';
// export const getOutwardTransactionList = OutwardController+'/getOutwardTransactionList';
// export const updateOutwardTransaction = OutwardController+'/updateOutwardTransaction';
// export const getOtwardTransactionDetail = OutwardController+'/getOtwardTransactionDetail';
// export const addOutwardTransaction = OutwardController+'/addOutwardTransaction';
// export const updateCDF = OutwardController+'/updateCDF';
// export const getOutwardQcList = OutwardController+'/getOutwardQcList';
// export const multiLotToCDF = OutwardController+'/multiLotToCDF';
// /*Branch */
// export const getBranchList = BranchController+'/getBranchList';
// export const getBranchDetail = BranchController+'/getBranchDetail';
// export const deleteBranch = BranchController+'/deleteBranch';
// export const addBranch = BranchController+'/addBranch';
// export const updateBranch = BranchController+'/updateBranch';

// //Contarct
// export const getContractList = ContractController+'/getContractList';
// export const getContractDetail = ContractController+'/getContractDetail';
// export const deleteContract = ContractController+'/deleteContract';
// export const addContract = ContractController+'/addContract';
// export const updateContract = ContractController+'/updateContract';
// export const copyContract = ContractController+'/copyContract';
// export const checktMultipleContract = ContractController+'/checktMultipleContract';
// export const getCurrentActiveContract = ContractController+'/getCurrentActiveContract';
// export const upgradeContract = ContractController+'/upgradeContract';
// export const getUpgradedContactList = ContractController+'/getUpgradedContactList';
// export const getUpgradedContactDetail = ContractController+'/getUpgradedContactDetail';

// /* transfer */
// export const addTransfer = TransferController+'/addTransfer';
// export const updateTransfer = TransferController+'/updateTransfer';
// export const getTransferList = TransferController+'/getTransferList';
// export const getTransferDetail = TransferController+'/getTransferDetail';
// export const deleteTransfer = TransferController+'/deleteTransfer';


// //Contarct
// export const getContractVMP = ContractController+'/getContractVMP';
// export const addContractVMP = ContractController+'/addContractVMP';
// export const updateContractVMP = ContractController+'/updateContractVMP';
// export const inwardQcList = InwardController+'/inwardQcList';
// export const getInwardQAQCList = CommodityparametersController+'/getInwardQAQCList';