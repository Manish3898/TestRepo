import { NgModule } from '@angular/core';
import { HttpModule, XHRBackend, RequestOptions, Http } from '@angular/http';

// Components

// Services
 import { CommanService } from './services/comman.service';
 /*import { ForgotpasswordService } from './services/forgotpassword.service';
 import { UserdetailsService } from './services/userdetails.service';*/
 import { AuthService } from './services/auth.service';

import { HttpService } from './services/http.service';
import { TestApiService } from './services/testapi.service';
import { Validator } from './services/validation.service';
/* pipes*/
import { FilterByCountry } from './pipes/filter-by-country.pipe';
import { ShowStatusPipe } from './pipes/show-status.pipe';

export function httpInterceptor(
  backend: XHRBackend,
  defaultOptions: RequestOptions,
) {
  return new HttpService(backend, defaultOptions); 
}

@NgModule({
  declarations: [
    // components
    // DummyService,
    // pipes
    FilterByCountry,
    ShowStatusPipe
    
    
  ],
  exports: [
    // components
    // DummyService,
    FilterByCountry,
    ShowStatusPipe

  ],
  imports: [
  HttpModule
  ],
  providers: [
  TestApiService,
  Validator,
  CommanService,
    /*ForgotpasswordService,
    UserdetailsService,
    TestUserService,
    TestSeriesService,
    TestHistoryService,
    AuthService,
    UserExamService,*/
    // UserService,
     AuthService,
    // Validator,
    // CommonService,
    {
      provide: HttpService,
      useFactory: httpInterceptor,
      deps: [ XHRBackend, RequestOptions]
    }
  ]
})
export class CoreModule {}
