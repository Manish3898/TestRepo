import { Pipe, PipeTransform } from '@angular/core';
import { Util } from '../resources/util';

@Pipe({
	name: 'showStatus',
	pure: false
})
export class ShowStatusPipe implements PipeTransform {
	public status;
	transform(value: any, statusJson?: any): any {
		if (!value) return '';
		this.status = Object.assign([], statusJson);
		if (!this.status.length) return;
		if (this.status.length) {
			if (!value || !this.status) return null;
			let utilObj = new Util();
			let index = utilObj.getIndexOfArrayData(this.status, 'id', value);
			if (index != -1) {
				return this.status[index].text;
			}
			return value;
		} else return '';
	}

}
