import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpService} from './http.service';
import 'rxjs/add/operator/map';


@Injectable()
export class AuthService {

/**
   *
   *
   * @param {any} data
   * @returns {Observable<any>}
   *
   */
  
   loginUser;
       
  constructor( private http: HttpService) { }
    //login Api
   
    isLogin(){
      this.loginUser = JSON.parse(localStorage.getItem('user'));
      if(this.loginUser != null ){
        /*if(this.loginUser.usr_type){*/
          if(this.loginUser){
          return true;
        }
      }else{
        return false;
      }
    }
   getLoginUserData(){
      if(JSON.parse(localStorage.getItem('user')) != null){
        return JSON.parse(localStorage.getItem('user'));
      }
    
}
}