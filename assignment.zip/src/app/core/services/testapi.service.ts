import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { HttpService} from '../../core/services/http.service';
import 'rxjs/add/operator/map';

@Injectable()
export class TestApiService {

  	constructor(private http: HttpService) { }

    companyRegistration(param): Observable < any > {
        return this.http.post('companyRegistration', param)
            .map((res: Response) => res.json());
    }
	login(param): Observable < any > {
        return this.http.post('login', param)
            .map((res: Response) => res.json());
    }
   /* checkLogin(): Observable < any > {
        return this.http.post('checkLogin', '')
            .map((res: Response) => res.json());
    }*/
    logout(param): Observable < any > {
        return this.http.post('logout', param)
            .map((res: Response) => res.json());
    }

    getList(param): Observable < any > {
        return this.http.post('getList', param)
            .map((res: Response) => res.json());
    }
    verifyUsername(param):Observable<any>{
        return this.http.post('checkUsernameExists', param)
        .map((res:Response)=>res.json());
    }
    empolyeeRegistration(param):Observable<any>{
        return this.http.post('empolyeeRegistration', param)
        .map((res:Response)=>res.json());
    }
    getEmpolyeeList(param):Observable<any>{
        return this.http.post('getEmpolyeeList', param)
        .map((res:Response)=>res.json());
    }
    getEmployeeDetails(param):Observable<any>{
        return this.http.post('getEmployeeDetails', param)
        .map((res:Response)=>res.json());
    }
    updateEmpolyee(param):Observable<any>{
        return this.http.post('updateEmpolyee', param)
        .map((res:Response)=>res.json());
    }
    getLanguageList(param):Observable<any>{
        return this.http.post('getLanguageList',param)
        .map((res:Response)=>res.json());
    }
    addproffessionalSkill(param):Observable<any>{
        return this.http.post('addproffessionalSkill',param)
        .map((res:Response)=>res.json());
    }
    getEmpProffesionalList(param):Observable<any>{
        return this.http.post('getEmpProffesionalList',param)
        .map((res:Response)=>res.json());
    }
    getupcomingBday(param):Observable<any>{
        return this.http.post('getupcomingBday',param)
        .map((res:Response)=>res.json());
    }
    getEmployeProfessional(param):Observable<any>{
        return this.http.post('getEmployeProfessional',param)
        .map((res:Response)=>res.json());
    }
    updateEmployeProfessional(param):Observable<any>{
        return this.http.post('updateEmployeProfessional',param)
        .map((res:Response)=>res.json());
    }
    addEmployeeSalary(param):Observable<any>{
         return this.http.post('addEmployeeSalary',param)
        .map((res:Response)=>res.json());
    }
    employeeSalaryList(param):Observable<any>{
        return this.http.post('employeeSalaryList',param)
        .map((res:Response)=>res.json());
    }
    getemployeeSalary(param):Observable<any>{
        return this.http.post('getemployeeSalary',param)
        .map((res:Response)=>res.json());
    }
    updateEmployeeSalaryById(param):Observable<any>{
        return this.http.post('updateEmployeeSalaryById',param)
        .map((res:Response)=>res.json());
    }
    getupcomingFirstIncr(param):Observable<any>{
        return this.http.post('getupcomingFirstIncr',param)
        .map((res:Response)=>res.json());
    }
    getupcomingIncrs(param):Observable<any>{
        return this.http.post('getupcomingIncrs',param)
        .map((res:Response)=>res.json());
    }
}