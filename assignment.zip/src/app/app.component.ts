// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.scss']
// })
// export class AppComponent {
//   title = 'assignment';
// }
import { Component } from '@angular/core';
import { AuthService } from './core/services/auth.service';
import { Router, NavigationEnd, RoutesRecognized } from '@angular/router';
import { TestApiService } from './core/services/testapi.service';
@Component({
	selector: 'app-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent {
	loginDetails;
	//var for set tab active status
	tabName: string = '/Dashboard';
	currentUrl;
	loginUser;
	params;
	previousUrlArray;
	previousUrl;
	checkUrls = [
		'/login',
		'/reg',
		'/'
	];
	user;
	constructor(public authService: AuthService,
		private router: Router,
		private testApiService: TestApiService) {
		//    router.events.filter(e => e instanceof NavigationEnd)
		// 		.subscribe((e: NavigationEnd) => {
		// 			this.currentUrl = e.url;
		// 			setTimeout(callback=>{
		// 				window.scrollTo(0, 0);    
		// 			},100)
		// 		});
	}

	isCheckRoute() {
		this.tabName = this.currentUrl;
		if (!this.currentUrl) {
			return false;
		}
		const index = this.checkUrls.indexOf(this.currentUrl);
		if (index >= 0) {
			return false;
		} else if (this.currentUrl.includes('passwordReset'))
			return false;
		else {
			return true;
		}

	}
	userLogout() {
		this.user = JSON.parse(localStorage.getItem('user'));
		this.testApiService.logout({ mid: this.user.m_id }).subscribe((result: any) => {
			if (result.status) {
				alert(result.message);
				localStorage.clear();
				this.router.navigate(['login']);
			} else {
				alert(result.message);
			}
		}, error => {
			alert(error);
		});
	}
}
