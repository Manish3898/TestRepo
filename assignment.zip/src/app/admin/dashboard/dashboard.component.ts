import { Component, OnInit } from '@angular/core';
import { TestApiService } from './../../core/services/testapi.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private testApiService:TestApiService) { }
  birthday:any=[];
  ngOnInit() {
  let user = JSON.parse(localStorage.getItem('user'));
  	let param ={
  		token:user.token,
    	usrid : user.usr_id,
  		cid:user.c_id,
  	}
  	this.testApiService.getupcomingBday(param).subscribe((result: any)=> { 
        if(result.status){
         this.birthday=result.data;
         }else{
          alert(result.message)
        }
      },error => {
        console.log(error);
      });
  }

}
