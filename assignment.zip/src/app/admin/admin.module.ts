import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './admin.component';
import { FormsModule, ReactiveFormsModule , NgForm}   from '@angular/forms';
import { CoreModule } from './../core/index';
import { EmpModule } from './emp/emp.module';
import { ProModule } from './pro/pro.module';
import { SalaryModule } from './salary/salary.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { NotificationModule } from './notification/notification.module';
const appRoutes: Routes = [

    {
        path: 'ad',
        component: AdminComponent,
        children: [
            { path: '', component: DashboardComponent },
            { path: 'dash', component: DashboardComponent },
            { path: 'emp', loadChildren:() => EmpModule},
            { path: 'pro', loadChildren:() => ProModule},
            { path: 'sal', loadChildren:() => SalaryModule},
            { path: 'noti', loadChildren:() => SalaryModule}]
    }];
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CoreModule,
    EmpModule,
    ProModule,
    SalaryModule,
    NotificationModule,
    RouterModule.forChild(appRoutes),
  ],
  declarations: [AdminComponent, DashboardComponent,  
  ],
  exports: [
      NgForm]
})
export class AdminModule { }
