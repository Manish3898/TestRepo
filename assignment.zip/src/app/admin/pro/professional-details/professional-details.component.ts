import { Component, OnInit } from '@angular/core';
import { TestApiService } from '.././../../core/services/testapi.service';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { Router,ActivatedRoute }  from '@angular/router';
import { CommanService } from '.././../../core/services/comman.service';

@Component({
  selector: 'app-professional-details',
  templateUrl: './professional-details.component.html',
  styleUrls: ['./professional-details.component.css']
})
export class ProfessionalDetailsComponent implements OnInit {

  constructor(private testApiService : TestApiService,
    private fb: FormBuilder,
    private router: Router, 
    private route : ActivatedRoute,
    private commanService : CommanService) { }
	employees;
  user;
	communications:any=[
	{id:1,name:'English'},
	{id:2,name:'Hindi'},
	{id:3,name:'Both'}];

  searchForm: FormGroup;
  languages:any=[
  {id : 1, name:'Java'},
  {id : 2, name:'Android'},
  {id : 3, name:'Angular'},
  {id : 4, name:'IOS'},
  {id : 5, name:'Node js'},
  {id : 6, name:'PHP'},
  ]
  
  skills={
    empName:'',
    empComm : 1,
    empSite:false
  };
  langChoices = [{empLang: '',year: 0}, {empLang: '',year: 0}];
  companyChoices = [{cname: '',title: '',loc: '',sdate: '',edate:''},{cname: '',title: '',loc: '',sdate: '',edate:''}];
  empDetails:any;
  empProfId;
  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));
  	this.getEmpolyeeList();
    this.getLanguages();
    this.route.params.subscribe(params => {
      this.empProfId = +params['pid'];
    });
    if(this.empProfId){
      this.getEmployeDetails(this.empProfId);
    }
  }
  addNewChoice() {
    let newItemNo = this.langChoices.length+1;
    this.langChoices.push({'empLang':'lang'+newItemNo,'year':newItemNo});
  };
  removeChoice() {
    let lastItem = this.langChoices.length-1;
    this.langChoices.splice(lastItem);
  };
  addEmployeeSkill(skillForm,status){
    debugger
    if(status == 'INVALID'){
      this.commanService.makeFormFieldTouched(skillForm.controls);
      return 
    }else{
      let data= this.createLangWorkArray(skillForm.value);
    let skill={
      token:this.user.token,
      usrid : this.user.usr_id,
      empid:skillForm.value.empName,
      compid:this.user.c_id,
      commSkill : skillForm.value.empComm,
      site : skillForm.value.empSite == true ? 1 : 0,
      lang:data[0],
      comp:data[1]
    }
    this.testApiService.addproffessionalSkill(skill).subscribe((result: any)=> { 
        if(result.status){
          alert(result.message);
          this.router.navigate(['/ad/pro/prolist'])
        }else{
          alert(result.message)
        }
      },error => {
        console.log(error);
      });
    }
    
  }
  createLangWorkArray(skillForm){
    let lanArray=[];
    let compArray=[];
    let arr=[];
    for(let i=1; i<=this.langChoices.length;i++){
     lanArray.push({lid : skillForm['lang'+i],lyr : skillForm['year'+i]});
    }
    for(let i=1; i<=this.companyChoices.length;i++){
      compArray.push({cname : skillForm['name'+i],title : skillForm['ttl'+i],loc : skillForm['lc'+i],sdate : skillForm['sdte'+i],edate : skillForm['edte'+i]});
    }
    arr=[
    lanArray,
    compArray ]
    return arr;
  }
  addNewCompany(){
    let newItemNo = this.companyChoices.length+1;
    this.companyChoices.push({'cname':'','title':'','loc':'','sdate':'','edate':''});
   
  }
  removeCompanySkill() {
    let lastItem = this.companyChoices.length-1;
    this.companyChoices.splice(lastItem);
  };
  
  getEmpolyeeList(){
    let param={
    		token : this.user.token,
    		usrid : this.user.usr_id,
    		cid : this.user.c_id
    	}
    this.testApiService.getEmpolyeeList(param).subscribe((result: any)=> { 
        if(result.status){
          this.employees = result.data;
        }else{
          alert(result.message)
        }
      },error => {
        console.log(error);
      });
  }
  getLanguages(){
    let param={
      token : this.user.token,
      usrid : this.user.usr_id
    }
    this.testApiService.getLanguageList(param).subscribe((result: any)=> { 
        if(result.status){
          this.languages = result.data;
        }else{
          alert(result.message)
        }
      },error => {
        console.log(error);
      });
  }
  getEmployeDetails(pid){
    let param={
      token : this.user.token,
      usrid : this.user.usr_id,
      empid : pid
    }
    let langArr=[];
    let workArr=[];
          
    this.testApiService.getEmployeProfessional(param).subscribe((result: any)=> { 
        if(result.status){
         this.skills={
            empName:pid,
            empComm : parseInt(result.data[0][0].p_commskl),
            empSite:result.data[0][0].p_onsite== 1 ? true : false
          };
          if(result.data[2]){
            result.data[2].forEach(function(data,index) {
              langArr.push({
                empLang: data.ws_langid,
                empYr: data.ws_year
              })
            });
          }
          if(result.data[1]){
             result.data[1].forEach(function(data,index) {
                workArr.push({cname: data.es_cname,
                title: data.es_title,
                loc: data.es_location,
                sdate: data.es_sdate,
                edate:data.es_edate
              })
            }); 
          }
          this.langChoices= langArr;
          this.companyChoices= workArr;
        }else{
          alert(result.message)
        }
      },error => {
        console.log(error);
      });
  }
  updateEmployeeSkill(skl,status){
    if(status == 'INVALID'){
      this.commanService.makeFormFieldTouched(skl.controls);
      return 
    }else{
      let data=this.createLangWorkArray(skl.value);
    let skill={
      token:this.user.token,
      usrid : this.user.usr_id,
      empid:skl.value.empName,
      compid:this.user.c_id,
      commSkill : skl.value.empComm,
      site : skl.value.empSite == true ? 1 : 0,
      lang:data[0],
      comp:data[1]
    }
    
    this.testApiService.updateEmployeProfessional(skill).subscribe((result: any)=> { 
        if(result.status){
         alert(result.message);
         this.router.navigate(['/ad/pro/prolist'])
        }else{
          alert(result.message)
        }
      },error => {
        console.log(error);
      });
    }
    
  }
  
}
