import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule , NgForm}   from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { ProfessionalDetailsComponent } from './professional-details/professional-details.component';
import { ProComponent } from './pro.component';

import { CoreModule } from '.././../core/index';
import { ProfessionalListComponent } from './professional-list/professional-list.component';


const appRoutes: Routes = [

    {
        path: 'pro',
        component: ProComponent,
        children: [{
                path: '',
                redirectTo: 'skill',
                pathMatch : 'full'
            },
            {
                path: 'skill',
                component: ProfessionalDetailsComponent
            },
            {
                path: 'eskill/:pid',
                component: ProfessionalDetailsComponent,
                pathMatch: 'full'
            },{
                path: 'prolist',
                component: ProfessionalListComponent,
                pathMatch: 'full'
            }]
    }];
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CoreModule,
    RouterModule.forChild(appRoutes),
  ],
  declarations: [ProfessionalDetailsComponent,ProComponent, ProfessionalListComponent]
})
export class ProModule { }
