import { Component, OnInit } from '@angular/core';
import { TestApiService } from '.././../../core/services/testapi.service';
import { Router }  from '@angular/router';
@Component({
  selector: 'app-professional-list',
  templateUrl: './professional-list.component.html',
  styleUrls: ['./professional-list.component.css']
})
export class ProfessionalListComponent implements OnInit {

  constructor(private testApiService :TestApiService,private router: Router) { }
  skills:any=[];
  ngOnInit() {
  	let user = JSON.parse(localStorage.getItem('user'));
  	let param ={
  		  token:user.token,
      	usrid : user.usr_id,
  		  cid:user.c_id,
  	  }
  	this.testApiService.getEmpProffesionalList(param).subscribe((result: any)=> { 
        if(result.status){
          this.skills=result.data;
        }else{
          alert(result.message)
        }
      },error => {
        console.log(error);
      });
  }
  gotoProfessionalEdit(empid){
  	this.router.navigate(['/ad/pro/eskill',empid])
  }

}
