import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotifyComponent } from './notify/notify.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule , NgForm}   from '@angular/forms';

const appRoutes: Routes = [

    {
        path: 'noti',
        component: NotifyComponent,
        children: [{
                path: '',
                redirectTo: 'not',
                pathMatch : 'full'
            },
            {
                path: 'not',
                component: NotifyComponent,
                pathMatch: 'full'
            }]
    }];
@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(appRoutes),
  ],
  declarations: [NotifyComponent]
})
export class NotificationModule { }
