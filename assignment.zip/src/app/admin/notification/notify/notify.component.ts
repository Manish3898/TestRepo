import { Component, OnInit } from '@angular/core';
import { TestApiService } from '.././../../core/services/testapi.service';
import { Router,ActivatedRoute }  from '@angular/router';

@Component({
  selector: 'app-notify',
  templateUrl: './notify.component.html',
  styleUrls: ['./notify.component.css']
})
export class NotifyComponent implements OnInit {

  constructor(private testApiService : TestApiService,private router : Router) { }

  firstIncr:any=[];
  nextIncr:any=[];
  user;
  ngOnInit() {
  	this.user = JSON.parse(localStorage.getItem('user'));
  	this.getupcomingFirstIncrRecord();
  }
  getupcomingFirstIncrRecord(){
  	let param={
    		token : this.user.token,
    		usrid : this.user.usr_id,
    		cid : this.user.c_id
    	}
  	this.testApiService.getupcomingFirstIncr(param).subscribe((result: any)=> { 
        if(result.status){
         this.firstIncr = result.data;
     	}else
          alert(result.message)
        
      },error => {
        console.log(error);
    });
  	this.testApiService.getupcomingIncrs(param).subscribe((result: any)=> { 
        if(result.status){
         this.nextIncr = result.data;
     	}else
          alert(result.message)
        
      },error => {
        console.log(error);
    });

  }
}
