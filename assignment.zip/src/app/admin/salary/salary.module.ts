import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SalaryComponent } from './salary.component';
import { AddSalaryComponent } from '.././salary/add-salary/add-salary.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule , NgForm}   from '@angular/forms';
import { SalaryListComponent } from './salary-list/salary-list.component';

const appRoutes: Routes = [

    {
        path: 'sal',
        component: SalaryComponent,
        children: [{
                path: '',
                redirectTo: 'addSal',
                pathMatch : 'full'
            },
            {
                path: 'addSal',
                component: AddSalaryComponent,
                pathMatch: 'full'
            },
            {
                path: 'salList',
                component: SalaryListComponent,
                pathMatch: 'full'
            },{
                path: 'eSal/:id',
                component: AddSalaryComponent,
                pathMatch: 'full'
            }]
    }];
@NgModule({
  imports: [
    CommonModule,
    FormsModule, 
    ReactiveFormsModule,
    RouterModule.forChild(appRoutes),
  ],
  declarations: [SalaryComponent,
  AddSalaryComponent,
  SalaryListComponent]
})
export class SalaryModule { }
