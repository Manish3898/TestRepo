import { Component, OnInit } from '@angular/core';
import { TestApiService } from '.././../../core/services/testapi.service';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router,ActivatedRoute }  from '@angular/router';
import {CommanService} from '../../../core/services/comman.service';

@Component({
  selector: 'app-add-salary',
  templateUrl: './add-salary.component.html',
  styleUrls: ['./add-salary.component.css']
})
export class AddSalaryComponent implements OnInit {

  constructor(private testApiService : TestApiService,private fb : FormBuilder,private router: Router, private route : ActivatedRoute,private commanService:CommanService) { }
  employees:any=[];
  user;
  salForm : FormGroup;
  empId;
  ngOnInit() {
	this.user = JSON.parse(localStorage.getItem('user'));
	this.getEmpolyeeList();
	this.salForm = this.fb.group({
		empid : ['',[Validators.required]],
		stipend : ['',[Validators.required]],
		sSdate : ['',[Validators.required]],
		sEdate : ['',[Validators.required]],
		fSal : [''],
		updateSal : [''],
		salIncrDate : [''],
		nextUpDate : [''],
	})
	this.route.params.subscribe(params => {
	  this.empId = +params['id'];
	});
	if(this.empId){
		this.getEmployeeSalaryDetail();
	}
}
getErrorMessage(type) {
    switch (type) {
      case "empid":
        return this.salForm.get('empid').hasError('required') ? 'Please select employee' : '';
      case "stipend":
        return this.salForm.get('stipend').hasError('required') ? 'stipend required' : '';
     case "sSdate":
        return this.salForm.get('sSdate').hasError('required') ? 'Start date of stipend required' : '';
      case "sEdate":
        return this.salForm.get('sEdate').hasError('required') ? 'End date of stipend required' : '';
      default:
        return 'Please fill all details';
    }
  }

  getEmpolyeeList(){
	let param={
			token : this.user.token,
			usrid : this.user.usr_id,
			cid : this.user.c_id
		}
	this.testApiService.getEmpolyeeList(param).subscribe((result: any)=> { 
		if(result.status){
		 this.employees = result.data;
		}else{
		  alert(result.message)
		}
	  },error => {
		console.log(error);
	  });
  }
  addSalary(empSal){
  	 if(!this.salForm.valid ){
    this.commanService.makeFormFieldTouched(this.salForm.controls)
    return;
  }else{
	empSal.token = this.user.token;
	empSal.usrid = this.user.usr_id;
	empSal.cid = this.user.c_id;
	this.testApiService.addEmployeeSalary(empSal).subscribe((result: any)=> { 
		if(result.status){
		 alert('Employee Salary added');
		 this.router.navigate(['/ad/sal/salList'])
		}else
		  alert(result.message)
		
	  },error => {
		console.log(error);
	  });
  }
}
  getEmployeeSalaryDetail(){
  	let param={
  		token : this.user.token,
  		usrid : this.user.usr_id,
  		empid : this.empId
  	}
	this.testApiService.getemployeeSalary(param).subscribe((result: any)=> { 
		if(result.status){
		 	this.salForm.patchValue({
				empid : result.data[0].s_empid,
				stipend : result.data[0].s_stipend,
				sSdate : result.data[0].s_stipend_sdate,
				sEdate : result.data[0].s_stipend_edate,
				fSal : result.data[0].s_first,
				updateSal : result.data[0].s_update_sal,
				salIncrDate : result.data[0].s_incr_date,
				nextUpDate : result.data[0].s_next_incr_date,
			})
		}else
		  alert(result.message)
		
	  },error => {
		console.log(error);
	  });
  }
  updateSalary(empSal){
  	empSal.token = this.user.token;
	empSal.usrid = this.user.usr_id;
	empSal.cid = this.user.c_id;
  	this.testApiService.updateEmployeeSalaryById(empSal).subscribe((result: any)=> { 
		if(result.status){
			alert('Employee Salary update successfully');
			this.router.navigate(['/ad/sal/salList'])
		}else
			alert(result.message)
		
	  },error => {
		console.log(error);
	  });
  }
  
}
