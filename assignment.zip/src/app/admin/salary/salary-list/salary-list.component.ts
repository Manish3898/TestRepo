import { Component, OnInit } from '@angular/core';
import { TestApiService } from '.././../../core/services/testapi.service';
import { Router,ActivatedRoute }  from '@angular/router';

@Component({
  selector: 'app-salary-list',
  templateUrl: './salary-list.component.html',
  styleUrls: ['./salary-list.component.css']
})
export class SalaryListComponent implements OnInit {

  constructor(private testApiService : TestApiService,private router : Router) { }
  salList:any=[];
  user;
  ngOnInit() {
  	this.user = JSON.parse(localStorage.getItem('user'));
  	this.getEmployeeSalaryList();
  }
  goToEditEmployeeSalary(id){
  	this.router.navigate(['ad/sal/eSal',id])
  }
  getEmployeeSalaryList(){
  	let param={
    		token : this.user.token,
    		usrid : this.user.usr_id,
    		cid : this.user.c_id
    	}
  	this.testApiService.employeeSalaryList(param).subscribe((result: any)=> { 
        if(result.status){
         this.salList = result.data;
     	}else
          alert(result.message)
        
      },error => {
        console.log(error);
    });
  }
}
