import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule , NgForm}   from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeComponent } from './employee/employee.component';
import { CoreModule } from '.././../core/index';

import { EmpComponent } from './emp.component';

const appRoutes: Routes = [

	{
		path: 'emp',
		component: EmpComponent,
		children: [{
				path: '',
				redirectTo: 'addemployee',
				pathMatch : 'full'
			},
			{
				path: 'addemployee',
				component: EmployeeComponent
			},{
				path: 'empe/:id',
				component: EmployeeComponent,
				pathMatch: 'full'
			},{
				path: 'emplist',
				component: EmployeeListComponent,
				pathMatch: 'full'
			}]
	}];
@NgModule({
  imports: [
	CommonModule,
	FormsModule,
	ReactiveFormsModule,
	CoreModule,
	RouterModule.forChild(appRoutes),
  ],
  declarations: [
  EmployeeComponent,
  EmployeeListComponent,
  EmpComponent],
  exports: [
		EmpComponent]
})
export class EmpModule { }
