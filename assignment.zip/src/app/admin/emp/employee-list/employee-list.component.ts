import { Component, OnInit } from '@angular/core';
import { TestApiService } from '.././../../core/services/testapi.service';
import { Router }  from '@angular/router';
import { CommanService } from '../../../core/services/comman.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(private testApiService:TestApiService,
    private router : Router,
    private commanService: CommanService) { }
  employees : any=[];
  ngOnInit() {
  	this.getEmpolyeeList();
  }
  getEmpolyeeList(){
  	let user = JSON.parse(localStorage.getItem('user'));
  	let param={
  		mid : user.m_id
  	}
  this.testApiService.getEmpolyeeList(param).subscribe((result: any)=> { 
        if(result.status){
         this.employees = result.data;
         }else{
          alert(result.message)
        }
      },error => {
        console.log(error);
    });
  }
  goToEditEmployee(empid){
    this.router.navigate(['/ad/emp/empe',empid]);
  }

}
