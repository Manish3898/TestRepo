import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Validator } from '../../../core/services/validation.service';
import { TestApiService } from '.././../../core/services/testapi.service';
import { CommanService } from '../../../core/services/comman.service';
import { Router, ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
@Component({
	selector: 'app-employee',
	templateUrl: './employee.component.html',
	styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

	constructor(private fb: FormBuilder,
		private router: Router,
		private route: ActivatedRoute,
		private validator: Validator,
		private testApiService: TestApiService,
		private commanService: CommanService) { }
	employee: FormGroup;
	userNameCheck: boolean = false;
	countries;
	states;
	user;
	empObj = {
		empid: 0,
		isDisabled: false
	}
	identificationArr = this.commanService.identificationArr;
	ngOnInit() {
		this.route.params.subscribe(params => {
			this.empObj.empid = +params['id'];

		});
		this.user = JSON.parse(localStorage.getItem('user'));
		this.commanService.getCountryJson().subscribe((res) => {
			this.countries = res.countries;
		});
		this.commanService.getStateJson().subscribe((res) => {
			this.states = res.states;
		});
		if (this.empObj.empid) {
			this.empObj.isDisabled = true;
			this.getEmployeDetailById();

		}
		this.employee = this.fb.group({
			fname: ['', [Validators.required]],
			lname: ['', [Validators.required]],
			dob: ['', [Validators.required]],
			mobno: ['', [Validators.required, this.validator.validateContact]],
			address: ['', [Validators.required]],
			city: [''],
		});
	}
	getErrorMessage(type) {
		switch (type) {
			case "fname":
				return this.employee.get('fname').hasError('required') ? 'First name required' : '';
			case "lname":
				return this.employee.get('lname').hasError('required') ? 'Last name required' : '';
			case "dob":
				return this.employee.get('dob').hasError('required') ? 'Date of birth required' : '';
			case "mobno":
				return this.employee.get('mobno').hasError('required') ? 'mobile no required' : !this.employee.get('mobno').valid ? 'mobile number must contain 10 digits' : '';
			case "address":
				return this.employee.get('address').hasError('required') ? 'Address required' : '';
			default:
				return 'Please fill all details';
		}
	}
	register(emp) {
		if (!this.employee.valid ) {
			this.commanService.makeFormFieldTouched(this.employee.controls)
			return;
		} else {
			emp.mid = this.user.m_id;
			this.testApiService.empolyeeRegistration(emp).subscribe((result: any) => {
				if (result.status) {
					alert(result.message);
					this.router.navigate(['/ad/emp/emplist'])
				} else {
					alert(result.message)
				}
			}, error => {
				console.log(error);
			});
		}

	}
	focusOutUserNameFunction(username) {
		if (!username || username.length < 6) {
			return false;
		}

		this.testApiService.verifyUsername({ username: username }).subscribe((result: any) => {
			if (result.status) {
				this.userNameCheck = false;
				result.data;
			} else {
				this.userNameCheck = true;
				console.log(result)
			}
		}, error => {
			console.log(error);
		});
	}
	filteredArry: Array<Object>;
	onCountryChange(countryId) {
		this.filteredArry = this.states.filter((value: any) => {
			return value.country_id === countryId
		});
		let selectedState: any;
		selectedState = this.filteredArry[0];
		this.employee.patchValue({
			state: selectedState.id
		});
	}
	getEmployeDetailById() {
		let param = {
			usrid: this.user.usr_id,
			token: this.user.token,
			cid: this.user.c_id,
			empid: this.empObj.empid
		}
		this.testApiService.getEmployeeDetails(param).subscribe((result: any) => {
			if (result.status) {
				this.employee.setValue({
					fname: result.data[0].fname,
					lname: result.data[0].lname,
					dob: result.data[0].dob,
					mobno: result.data[0].mobile,
					city: result.data[0].city,
					address: result.data[0].address,
					
				});
			} else {
				alert(result.message)
			}
		}, error => {
			console.log(error);
		});
	}

	updateEmployee(emp) {
		if (!this.employee.valid) {
			this.commanService.makeFormFieldTouched(this.employee.controls)
			return;
		} else {
			emp.empid = this.empObj.empid;
			this.testApiService.updateEmpolyee(emp).subscribe((result: any) => {
				if (result.status) {
					alert(result.message);
					this.router.navigate(['/ad/emp/emplist'])
				} else {
					alert(result.message)
				}
			}, error => {
				console.log(error);
			});
		}
	}
}
