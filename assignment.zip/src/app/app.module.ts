import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule }   from '@angular/forms';
import { CoreModule } from './core/index';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { TestlistComponent } from './testlist/testlist.component';
import { RegistrationComponent } from './registration/registration.component';
import { AdminModule } from './admin/admin.module';
const appRoutes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'reg', component: RegistrationComponent },
    { path: 'login', component: LoginComponent },
    { path: 'testlist', component: TestlistComponent },
    { path: 'testlist', component: TestlistComponent },
    { path: 'ad', loadChildren: ()=> AdminModule},
    
    ]
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    TestlistComponent,
    RegistrationComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(
    appRoutes 
    ),
    HttpClientModule,
    AdminModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
