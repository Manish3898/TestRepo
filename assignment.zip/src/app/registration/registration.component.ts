	import { Component, OnInit } from '@angular/core';
	import { Router }  from '@angular/router';
	import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
	import { Validator } from '../core/services/validation.service';
	import {CommanService} from '../core/services/comman.service';
	import { TestApiService } from './../core/services/testapi.service';
	@Component({
		selector: 'app-registration',
		templateUrl: './registration.component.html',
		styleUrls: ['./registration.component.scss']
	})
	export class RegistrationComponent implements OnInit {

	 constructor(private formBuilder: FormBuilder,private testApiService:TestApiService ,private commanService:CommanService,private router: Router,private validator:Validator) { }
		countries;
		states;
		regUser: FormGroup;
		myProfileViewObj={
				displayImage:"",
				uploadedFile:""
		}
		params;
		userNameCheck;
		ngOnInit() {
			this.commanService.getCountryJson().subscribe((res)=>{
				this.countries = res.countries;  
			});
			this.commanService.getStateJson().subscribe((res)=>{
				this.states = res.states;    
			});
			
			this.regUser = this.formBuilder.group({
				fname : ['',[Validators.required,Validators.maxLength(30)]],
				lname : [''],
				email: ['', [Validators.required,this.validator.validateEmail]],
				password: ['', [Validators.required]],
				address:['', [Validators.required]],
				dob:[''],
				company:['' ]
			});
		}
		getErrorMessage(type) {
    switch (type) {
      case "fname":
        return this.regUser.get('fname').hasError('required') ? 'Name required' : this.regUser.get('fname').hasError('maxlength') ? 'Company name maximum length 30':'';
      case "email":
        return this.regUser.get('email').hasError('required') ? 'Email required' : !this.regUser.get('email').valid ? 'Please enter valid Email':'';
        case "password":
        return this.regUser.get('password').hasError('required') ? 'Password required' : '';
        case "address":
        return this.regUser.get('address').hasError('required') ? 'Address required' : '';
       default:
        return 'Please fill all details';
    }
  }
		//check userName avl or not
		focusOutUserNameFunction(username){
			if(!username || username.length < 6){
				return false;
			}
			
			this.testApiService.verifyUsername({username : username}).subscribe((result: any)=> { 
					if(result.status){
						this.userNameCheck = false;
						result.data;
					}else{
						this.userNameCheck = true;
						console.log(result)
					}
				},error => {
					console.log(error);
				});
		}

			 //call institute registration Api
		register(){
			debugger
			if(!this.regUser.valid)
			{
				this.commanService.makeFormFieldTouched(this.regUser.controls);
				return;
			}else{
				let instituteDetails = this.regUser.value;
		 let param={
					m_fname:instituteDetails.fname,
					m_lname:instituteDetails.lname,
					m_address:instituteDetails.address,
					m_pass:instituteDetails.password,
					m_email:instituteDetails.email,
					m_dob:instituteDetails.dob,
					m_company:instituteDetails.company,

				}
				
				this.testApiService.companyRegistration(param).subscribe((result: any)=> { 
					if(result.status){
						alert('Registration Successfully')
						this.router.navigate(['/login']);
					}else{
						alert(result.message)
					}
				},error => {
					console.log(error);
				});
			}
		 
			
	}
			 
goBack(){
	this.router.navigate(['/login']);
}
		filteredArry: Array<Object>;
		onCountryChange(countryId){
					this.filteredArry = this.states.filter((value:any) => {
							return value.country_id === countryId
					});
					let selectedState:any;
					selectedState=this.filteredArry[0];
					this.regUser.patchValue({
							state: selectedState.id
					});
			}

			detail(){
				let a=10;
				let b=a*a;
				console.log(b);
				var data=(this.getData(a,b),()=>{
					let c = data;
				console.log(c);
				});
				console.log(123);
			}

		async getData(a,b){

				setTimeout(()=>{
					console.log((a+b)+5)
					return (a+b)+5;
				},2000)
			}

			afterTwoSec(a,b){
				return new Promise(resolve => {
				setTimeout(()=>{
					let c = a+b;
					resolve((a+b)+5);
				 },2000)
			});
			}
			async getAsyncData(){

				let a=10,b=20;
				let c=a+ b;
				console.log(c);
				let data = await this.afterTwoSec(a,b);
				
				console.log('After setTimeOut function')
				console.log(data);
				console.log('last line call')

			}
	}
