import { Component, OnInit } from '@angular/core';
import { TestApiService } from './../core/services/testapi.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-testlist',
  templateUrl: './testlist.component.html',
  styleUrls: ['./testlist.component.scss']
})
export class TestlistComponent implements OnInit {

  constructor(private testApiService : TestApiService,private router:Router) { }
  users;
  user;
  ngOnInit() {
  	this.user = JSON.parse(localStorage.getItem('user'));
  	this.testApiService.getList({id : this.user.usr_id ,token: this.user.token}).subscribe((result: any)=> { 
      if(result.status){
      	this.users=result.data;
      	 alert(result.message);
      	 }else{
        alert(result.message);
      }
    },error => {
      alert(error);
    });
  }
 
}
