var express = require('express');
var bodyParser = require('body-parser');
var con = require('./db');
var isset = require('isset');
var encode = require('nodejs-base64-encode');
var md5 = require('md5');
var moment = require('moment');
var app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(function(req,res,next){
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});

app.get('/api/test', function(req, res){
    insertRow();
    res.write("<br/>Running successfully");
    res.end();
})
//komaljadam komal@2

app.post('/api/login',function(req,res){
    console.log(req);
    var email = isset(req.body.email)?req.body.email:"";
    var password = isset(req.body.password)?req.body.password:"";
    if (!email) 
        res.json({ status : false, message : 'username required.' });
    else if (!password) 
        res.json({ status : false, message : 'password required.' })
    else
    {
      /*var usrid=fname.substring(0, 3);
      //var usrid = userResult[0].usr_id;
      var md5Hash = md5('testwave:'+usrid+':&S9#:@plite:2017');
      var hash = 'testwave:'+usrid+':'+md5Hash;
      var token = encode.encode(hash, 'base64');*/
    //var sql=  "INSERT INTO tbl_user (usr_name, isactive, token) VALUES ('"+fname+"', '1', '"+token+"')";
    var sql = "SELECT * FROM manager WHERE m_email = '"+email+"' AND m_password = '"+password+"'";
    con.query(sql, function (err, result) 
    {
        if (result.length) 
        {
                var sql2="UPDATE manager SET m_isActive='"+1+"' where m_email = '"+email+"'";
                con.query(sql2, function (err, resultset){
                    if(resultset)
                    {
                        var sql = "SELECT * FROM manager WHERE m_email = '"+email+"' AND m_password = '"+password+"'";
                        con.query(sql, function (err, resultAU) 
                        {
                            if(resultAU)
                            res.json({ status : true, data : resultAU , message : 'Login successfully.'});
                            else
                            res.json({status : false , message : 'something went wrong'});
                        })
                        
                      
                    }else
                    {
                        console.log(err)
                        res.json({status : false , message : 'something went wrong'})}
                });
                
            }else{
                res.json({status : false , message : 'email or password not match'})
            }
        });
}

});
app.post('/api/getList',function(req,res){
    var usrid = isset(req.body.id)?req.body.id:"";
    var token = isset(req.body.token)?req.body.token:"";
    if (!usrid) 
        res.json({ status : false, message : 'user id required.' });
    else if (!token) 
        res.json({ status : false, message : 'token required.' })
    else
    {
        verifyToken(token,usrid, function(tokenResult){
            if(tokenResult){
                var sql="SELECT usr_name FROM tbl_user where usr_id !='"+usrid+"'";
                con.query(sql, function (err, result){
                    if(result)
                        res.json({status : true , data : result,message : 'user test list'})
                    else
                        res.json({status : false , message : 'No user found'})
                });
            }

            else
                res.json({ status : false, message : 'token mismatch' });
        });
    }
});
/*app.post('/api/checkLogin' , function(req,res){
  //sess=req.session;
  
  console.log(sess)
  if(sess){
    sess.email = sess.email;
    if(sess.email)
    {
      res.json({status : true , data : sess.email})
    }else
    {
      res.json({status : false , message : 'login first'})
    }
  }else{
    res.json({status : false , message : 'Please login'})
  }
})*/


app.post('/api/logout',function(req,res){
    var mid = isset(req.body.mid)?req.body.mid:"";
    if (!mid) 
        res.json({ status : false, message : 'user id required.' });
    else
    {
                var sql="UPDATE manager SET m_isactive='0' WHERE m_Id ='"+mid+"'";
                con.query(sql, function (err, result){
                    if(result)
                        res.json({status : true , data : result,message : 'user logout'})
                    else
                        res.json({status : false , message : 'error'})
                });
            }

           


});
app.post('/api/companyRegistration',function(req,res){
    console.log(req.body);
    var fname = isset(req.body.m_fname)?req.body.m_fname:"";
    var lname = isset(req.body.m_lname)?req.body.m_lname:"";
    var email = isset(req.body.m_email)?req.body.m_email:"";
    var address = isset(req.body.m_address)?req.body.m_address:"";
    var company = isset(req.body.m_company)?req.body.m_company:"";
    var dob = isset(req.body.m_dob)?req.body.m_dob:"";
    var pass = isset(req.body.m_pass)?req.body.m_pass:"";
     if (!email) 
        res.json({ status : false, message : 'company email required.' })
    else
    {
         var sql = "INSERT INTO manager (m_fname,m_lname, m_email, m_dob, m_company, m_address,m_password) VALUES ( '"+fname+"', '"+lname+"', '"+email+"', '"+dob+"', '"+company+"', '"+address+"', '"+pass+"')";
            con.query(sql, function (err, result) 
            {
                console.log(result);
                console.log(err);
                if (result) 
                    res.json({ status : true, message : 'Manager registered successfully .' });
                else{
                    if (err) {
                            res.json({ status : false, message : 'Error in Manager registration, Please try again.' });
                        }else{
                            res.json({ status : false, message : 'Something went wrong.' });
                        }
                
                    
                }
            });
        }
    
});

app.post('/api/empolyeeRegistration',function(req,res){
    console.log(req.body);
    var mid = isset(req.body.mid)?req.body.mid:"";
    var fname = isset(req.body.fname)?req.body.fname:"";
    var lname = isset(req.body.lname)?req.body.lname:"";
    var dob = isset(req.body.dob)?req.body.dob:"";
    var city = isset(req.body.city)?req.body.city:"";
    var mobno = isset(req.body.mobno)?req.body.mobno:"";
    var address = isset(req.body.address)?req.body.address:"";
    if (!fname) 
        res.json({ status : false, message : 'fname required.' })
    else if (!address) 
        res.json({ status : false, message : 'address required.' })
    else
    {
        var sql = " INSERT INTO employee(m_Id, fname, lname, dob, mobile,city,address) VALUES ('"+ mid +"', '"+fname+"', '"+lname+"', '"+dob+"', '"+mobno+"', '"+city+"', '"+address+"')";

            con.query(sql, function (err, result) 
            {
                if (result) 
                    res.json({ status : true, message : 'Empolyee registered successfully .' });
                else
                {    
                    console.log(err)
                    res.json({ status : false, message : 'Error in Empolyee registration, Please try again.' });
           } });
    }  
});
app.post('/api/getEmpolyeeList',function(req,res){
    
    var mid = isset(req.body.mid)?req.body.mid:"";
    if (!mid) 
        res.json({ status : false, message : 'Manager id required.' })
    else
    {
        var sql="SELECT * FROM employee where m_Id ='"+mid+"'";
        con.query(sql, function (err, result){
            if(result)
                res.json({status : true , data : result})
            else
                res.json({status : false , message : 'No Empolyee found'})
        });
    }

            
});

app.post('/api/getEmployeeDetails',function(req,res){
    var empid = isset(req.body.empid)?req.body.empid:"";
    if (!empid) 
        res.json({ status : false, message : 'Empolyee id required.' })
    else
    {
        var sql="SELECT * FROM employee where empId ='"+empid+"'";
        con.query(sql, function (err, result){
            if(result)
                res.json({status : true , data : result})
            else
                res.json({status : false , message : 'No Empolyee found'})
        });
            
    }
});

app.post('/api/updateEmpolyee',function(req,res){
    console.log(req.body);
    
    var empid = isset(req.body.empid)?req.body.empid:"";
    var fname = isset(req.body.fname)?req.body.fname:"";
    var lname = isset(req.body.lname)?req.body.lname:"";
    var dob = isset(req.body.dob)?req.body.dob:"";
   var city = isset(req.body.city)?req.body.city:"";
    var address = isset(req.body.address)?req.body.address:"";
   var mobno = isset(req.body.mobno)?req.body.mobno:"";
    
    if (!empid) 
        res.json({ status : false, message : 'Employee id required.' })
    else
    {var sql = "Update employee SET fname='"+fname+"',lname='"+lname+"',dob='"+dob+"' ,city='"+city+" ',address='"+address+"' WHERE empId="+empid;
    // "Update employee SET fname="+fname+",lname="+lname+",dob="+dob+" ,city="+city+" ,address="+address+" WHERE empId="+empid
    con.query(sql, function (err, result) 
        {
            console.log(err);
            if (result) 
                res.json({ status : true, message : 'Empolyee update successfully .' });
            else
                res.json({ status : false, message : 'Error in Empolyee updation, Please try again.' });
        });
   

    }  
});

app.post('/api/getUserDetails',function(req,res){
    var usrid = isset(req.body.userid)?req.body.userid:'';
    if(!usrid)
        res.json({status: false , message : 'user id required'});
    else
        var sql =  "SELECT * FROM tbl_company where usr_id = '"+usrid+"'";
    con.query(sql, function(err, result){
        if(result.length == 1){
            res.json({status: true , message : result});
        }
        else
            res.json({status: false , message : 'User not found'});
    })
})

app.listen(3000,function(){
    console.log("App Started on PORT 3000");
});

