var mysql = require('mysql');

//--db connection
var connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "assignment",
  multipleStatements: true
});
var pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'assignment'
});

//module.exports = connection;
module.exports = pool;